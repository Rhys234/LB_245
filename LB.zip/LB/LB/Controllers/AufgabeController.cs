﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace LB.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AufgabeController : ControllerBase
    {
        // localhost:44360/api/aufgabe

        private readonly AufgabeContext _db;

        public AufgabeController(AufgabeContext context)
        {
            _db = context;
        }

        [HttpPost]
        public IActionResult CreateAufgabe(Aufgabe aufgabe)
        {
            _db.Aufgabe.Add(aufgabe);
            _db.SaveChanges();

            return CreatedAtAction("GetBook", new { id = aufgabe.id }, aufgabe);

        }

        [HttpGet]
        public IActionResult GetAufgabe(int id)
        {
            Aufgabe aufgabeFromDb = _db.Aufgabe.SingleOrDefault(a => a.id == id);

            if(aufgabeFromDb == null )
            {
                return NotFound();
            }

            return Ok(aufgabeFromDb);
        }
    }
}
