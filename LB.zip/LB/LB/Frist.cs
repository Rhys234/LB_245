﻿namespace LB
{
    public class Frist
    {
        public int Datum { get; set; }
    }
}
