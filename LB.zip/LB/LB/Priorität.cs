﻿namespace LB
{
    public class Priorität
    {
        public int Prio {  get; set; }
    }
}
