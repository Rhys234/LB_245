﻿using Microsoft.EntityFrameworkCore;

namespace LB
{
    public class PrioContext : DbContext
    {
        public PrioContext(DbContextOptions<AufgabeContext> options) : base(options)
        {
        }
        public System.Data.Entity.DbSet<Aufgabe> Aufgabe { get; set; }
    }
}
