﻿namespace LB
{
    public class Autor
    {
        public string Name { get; set; }
    }
}
