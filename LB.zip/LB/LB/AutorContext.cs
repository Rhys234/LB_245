﻿using Microsoft.EntityFrameworkCore;

namespace LB
{
    public class AutorContext : DbContext
    {
        public AutorContext(DbContextOptions<AufgabeContext> options) : base(options)
        {
        }
        public System.Data.Entity.DbSet<Aufgabe> Aufgabe { get; set; }
    }
}
