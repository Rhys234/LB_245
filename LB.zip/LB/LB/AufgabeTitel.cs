﻿namespace LB
{
    public class AufgabeTitel : Aufgabe
    {
        public int id { get; set; }
        public string Title { get; set; }
    }
}
