﻿using Microsoft.EntityFrameworkCore;


namespace LB
{
    public class AufgabeContext : DbContext
    {
        public AufgabeContext(DbContextOptions<AufgabeContext> options) : base(options)
        {
        }
        public System.Data.Entity.DbSet<Aufgabe> Aufgabe { get; set;}
    }
}
