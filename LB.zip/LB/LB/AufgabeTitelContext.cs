﻿using Microsoft.EntityFrameworkCore;

namespace LB
{
    public class AufgabeTitelContext : DbContext
    {
        public AufgabeTitelContext(DbContextOptions<AufgabeContext> options) : base(options)
        {
        }
        public System.Data.Entity.DbSet<Aufgabe> AufgabeTitel { get; set; }
    }
}
