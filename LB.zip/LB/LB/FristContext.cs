﻿using Microsoft.EntityFrameworkCore;

namespace LB
{
    public class FristContext : DbContext
    {
        public FristContext(DbContextOptions<AufgabeContext> options) : base(options)
        {
        }
        public System.Data.Entity.DbSet<Aufgabe> Aufgabe { get; set; }
    }
}
