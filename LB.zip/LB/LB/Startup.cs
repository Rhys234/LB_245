﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.InMemory;

namespace LB
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            // Configure the database context
            services.AddDbContext<AufgabeContext>(options =>
            {
                options.UseSqlServer(Configuration.GetConnectionString("AufgabeDb"));
            });

            // Add controllers
            services.AddControllers();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            // Configure middleware based on the environment

            if (env.IsDevelopment())
            {
                // Show detailed exception information in development environment
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // In production, handle exceptions more gracefully
                app.UseExceptionHandler("/error");
                app.UseHsts(); // Enforce HTTPS in production
            }

            // Redirect HTTP to HTTPS
            app.UseHttpsRedirection();

            // Configure routing
            app.UseRouting();

            // Add endpoint routing
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }

}
