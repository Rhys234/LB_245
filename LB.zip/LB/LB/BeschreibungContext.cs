﻿using Microsoft.EntityFrameworkCore;

namespace LB
{
    public class BeschreibungContext : DbContext
    {
        public BeschreibungContext(DbContextOptions<AufgabeContext> options) : base(options)
        {
        }
        public System.Data.Entity.DbSet<Aufgabe> Aufgabe { get; set; }
    }
}
