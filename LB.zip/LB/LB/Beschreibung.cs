﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LB
{
    public class Beschreibung
    {
        public int Id { get; set; }
        public int beschreibung { get; set; }
    }
}
